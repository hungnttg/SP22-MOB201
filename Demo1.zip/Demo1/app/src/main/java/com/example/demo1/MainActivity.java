package com.example.demo1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {
    Button btnStart,btnStop;
    EditText txt1,txt2;
    Intent intent1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btnStart = findViewById(R.id.lab11btnStart);
        btnStop = findViewById(R.id.lab11btnStop);
        txt1 = findViewById(R.id.lab11txt1);
        txt2 = findViewById(R.id.lab11txt2);
        //truyen du lieu vao service1
        intent1 = new Intent(this,MyService1.class);
        btnStart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //1. Lay du lieu nhap tren txt1,txt2
                String masv = txt1.getText().toString();
                String tensv = txt2.getText().toString();
                //2. Dua du lieu vao intent
                intent1.putExtra("masv",masv);
                intent1.putExtra("tensv",tensv);
                //3. Truyen cho service
                startService(intent1);//khoi dong service
            }
        });
        btnStop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                stopService(intent1);//tat service
            }
        });

    }
}
