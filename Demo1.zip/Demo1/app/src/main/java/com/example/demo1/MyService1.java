package com.example.demo1;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.widget.Toast;

import androidx.annotation.Nullable;

public class MyService1 extends Service {
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
    //1.khoi tao (startService)
    @Override
    public void onCreate() {
        super.onCreate();
    }
    //2. nhan va xu ly du lieu (startService)
    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String ma = intent.getStringExtra("masv");
        String ten = intent.getStringExtra("tensv");
        Toast.makeText(this,"Truyen du lieu: ma sv: "+ma+"; Ten: "+ten,Toast.LENGTH_LONG).show();
        return super.onStartCommand(intent, flags, startId);
    }
    //3.Ham Huy (stopService)
    @Override
    public void onDestroy() {
        Toast.makeText(this,"Huy dich vu",Toast.LENGTH_LONG).show();
        super.onDestroy();
    }
}
