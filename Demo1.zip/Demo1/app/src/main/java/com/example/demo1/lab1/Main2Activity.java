package com.example.demo1.lab1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.example.demo1.R;

public class Main2Activity extends AppCompatActivity {
    Button btnFind;
    EditText txt,txtChuoi;

    Intent intent2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        btnFind = findViewById(R.id.lab12btn);
        txt = findViewById(R.id.lab12txt);
        txtChuoi =findViewById(R.id.lab12txtChuoi);
        //dinh nghia truyen du lieu
        intent2 = new Intent(this,MyService2.class);
        btnFind.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Lay ky tu nhap vao
                String inputChar = txt.getText().toString();
                char[] c = inputChar.toCharArray();//chuyen chuoi thanh mang ky tu
                //lay chuoi nhap vao
                String check = txtChuoi.getText().toString();
                intent2.putExtra("char",c[0]);//truyen ky tu can tim kiem
                intent2.putExtra("check",check);//truyen chuoi can kiem tra
                startService(intent2);

            }
        });
    }
}
