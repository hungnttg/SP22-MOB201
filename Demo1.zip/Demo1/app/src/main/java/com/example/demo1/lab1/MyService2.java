package com.example.demo1.lab1;

import android.app.IntentService;
import android.content.Intent;
import android.widget.Toast;

import androidx.annotation.Nullable;

public class MyService2 extends IntentService {
    public MyService2()
    {
        super("MyService2");
    }
    int count = 0;
    @Override
    protected void onHandleIntent(@Nullable Intent intent) {
        char c1 = intent.getCharExtra("char",'0');//lay ky tu truyen
        String check = intent.getStringExtra("check");//lay chuoi
        count = countCharacter(check,c1);//dem ky tu
    }
    @Override
    public void onDestroy() {
        Toast.makeText(this,"So ky tu la: "+count,Toast.LENGTH_LONG).show();
        Toast.makeText(this,"Huy service",Toast.LENGTH_LONG).show();
        super.onDestroy();
    }
    public int countCharacter(String str,char c)
    {
        int count = 0;
        for(int i=0;i<str.length();i++)
        {
            if(str.charAt(i)==c)//charAt(i): tai vi tri i cua chuoi la ky tu c
            {
                count++;
            }
        }
        return count;
    }
}
