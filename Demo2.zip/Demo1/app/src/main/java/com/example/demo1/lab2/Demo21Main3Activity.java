package com.example.demo1.lab2;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;

import com.example.demo1.R;

public class Demo21Main3Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_demo21_main3);
        phanQuyen();
        Intent intent = new Intent(this,MyBroadcast1.class);
        sendBroadcast(intent);
    }
    //Ham phan quyen cho phep truy cap trang thai cuoc goi den
    public boolean phanQuyen()
    {
        if(Build.VERSION.SDK_INT>=23)//hien nay dang la 31
        {
            //neu quyen READ_PHONE_STATE da duoc chon va
            //quyen READ_PHONE_NUMBER da duoc chon
            if(checkSelfPermission(Manifest.permission.READ_PHONE_STATE)== PackageManager.PERMISSION_GRANTED
            && checkSelfPermission(Manifest.permission.READ_PHONE_NUMBERS)==PackageManager.PERMISSION_GRANTED)
            {
                return true;
            }
            else
            {
                //neu chua duoc chon thi hien thi thong bao xin cap quyen
                ActivityCompat.requestPermissions(Demo21Main3Activity.this,
                        new String[]{Manifest.permission.READ_PHONE_STATE,Manifest.permission.READ_PHONE_NUMBERS},1);
                return  false;
            }
        }
        else
        {
            Log.d("PHAN QUYEN","QUyen duoc gan roi");
            return true;
        }
    }
}
