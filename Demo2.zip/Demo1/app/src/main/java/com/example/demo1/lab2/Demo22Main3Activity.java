package com.example.demo1.lab2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.example.demo1.R;

public class Demo22Main3Activity extends AppCompatActivity {
    Button button;
    EditText editText;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_demo22_main3);
        button = findViewById(R.id.demo22Btn1);
        editText = findViewById(R.id.demo22Txt1);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //1. Lay du lieu nguoi dung nhap
                String dulieu = editText.getText().toString();
                //2. goi intent
                Intent intent = new Intent(Demo22Main3Activity.this,MyBroadcast3.class);
                //3. Dua du lieu vao intent
                intent.putExtra("broad",dulieu);
                //4.send
                sendBroadcast(intent);
            }
        });
    }
}
