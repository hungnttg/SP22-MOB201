package com.example.demo1.lab2;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.widget.Toast;

public class MyBroadcast2 extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        //1. Nhan thong tin
        String message = intent.getExtras().getString("broad");
        //2.Dua ra thong bao
        Toast.makeText(context,"Da chuyen qua Broadcast: - "+message,Toast.LENGTH_LONG).show();
    }
}
