package com.example.demo1.lab2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.example.demo1.R;

public class Demo23Main3Activity extends AppCompatActivity {
    Button button;
    EditText editText;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_demo23_main3);
        button = findViewById(R.id.demo23Btn);
        editText = findViewById(R.id.demo23Txt);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String dulieu = editText.getText().toString();
                Intent intent = new Intent(Demo23Main3Activity.this,MyBroadcast3.class);
                //dua du lieu vao intent
                intent.putExtra("br",dulieu);
                //sendBroadcast
                sendBroadcast(intent);
            }
        });
    }
}
