package com.example.demo1.lab3;

import androidx.appcompat.app.AppCompatActivity;

import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.ContactsContract;

import com.example.demo1.R;

public class Demo32Main3Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_demo32_main3);
    }
//    public String getPhoneNumber(Uri uriContact,String idContact)
//    {
//        String contactNum = null;
//        //lay contact id
//        //Cursor cursorID = getContentResolver().query(uriContact,new String[]{ContactsContract.Con},null,null,null);
//    }
}
