package com.example.demo1.asm1;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.GridView;

import com.example.demo1.R;

public class DemoAsm1Main3Activity extends AppCompatActivity {
    GridView gridView;
    //tao nguon du lieu
    int flags[]={
         R.drawable.america,
            R.drawable.australia,
            R.drawable.china,
            R.drawable.new_zealand,
            R.drawable.portugle,
            R.drawable.india,
            R.drawable.america,
            R.drawable.australia,
            R.drawable.china,
            R.drawable.new_zealand,
            R.drawable.portugle,
            R.drawable.india,
            R.drawable.america,
            R.drawable.australia,
            R.drawable.china,
            R.drawable.new_zealand,
            R.drawable.portugle,
            R.drawable.india,
    };
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_demo_asm1_main3);
        gridView = findViewById(R.id.demoAsmGridView);
        DemoAsm1Adapter asm1Adapter = new DemoAsm1Adapter(getApplicationContext(),flags);
        gridView.setAdapter(asm1Adapter);
    }
}
