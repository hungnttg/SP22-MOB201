package com.example.demo1.lab4;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.widget.TextView;

import com.example.demo1.R;

public class Demo41Main3Activity extends AppCompatActivity
implements LocationListener{
    LocationManager locationManager;
    TextView tvLong, tvLat;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_demo41_main3);
        tvLat = findViewById(R.id.demo41TvLat);
        tvLong = findViewById(R.id.demo41TvLong);
        /////////Goi service
        //1. goi service
        locationManager = (LocationManager)getSystemService(LOCATION_SERVICE);
        //2. phan quyen
        if(ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
        != PackageManager.PERMISSION_GRANTED
        && ActivityCompat.checkSelfPermission(this,Manifest.permission.ACCESS_COARSE_LOCATION)
        != PackageManager.PERMISSION_GRANTED)
        {
            return;//khong co quyen thi khong lam
        }
        //3. neu co quyen, ta cap nhat vi tri
        locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER,1000,1,
                (LocationListener) this);
    }
    //Ham thay doi vi tri khi nguoi dung di chuyen
    @Override
    public void onLocationChanged(@NonNull Location location) {
        double longtitu = location.getLongitude();
        double lattitu = location.getLatitude();
        tvLat.setText("Toa do Lat: "+String.valueOf(lattitu));
        tvLong.setText("Toa do Long: "+String.valueOf(longtitu));
    }


}
