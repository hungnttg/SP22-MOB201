package com.example.demo1.lab4;

import androidx.appcompat.app.AppCompatActivity;

import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.widget.TextView;

import com.example.demo1.R;

public class Demo42Main3Activity extends AppCompatActivity {
    TextView textView;
    ConnectivityManager connectivityManager;//dv quan ly ket noi
    NetworkInfo mywifi, my4g;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_demo42_main3);
        textView = findViewById(R.id.demo42Tv);
        //1. goi service
        connectivityManager = (ConnectivityManager)getSystemService(CONNECTIVITY_SERVICE);
        //2. xac dinh loai ket noi
        mywifi = connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_WIFI);
        my4g = connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_MOBILE);
        if(mywifi.isConnected()==true)
        {
            textView.setText("Dang dung wifi");
        }
        if(my4g.isConnected()==true)
        {
            textView.setText("Dang dung 4G");
        }
    }
}
