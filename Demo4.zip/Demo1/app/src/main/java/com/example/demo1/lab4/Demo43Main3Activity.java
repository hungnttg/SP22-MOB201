package com.example.demo1.lab4;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Build;
import android.os.Bundle;
import android.widget.TextView;

import com.example.demo1.R;

public class Demo43Main3Activity extends AppCompatActivity {
    TextView textView;
    @RequiresApi(api = Build.VERSION_CODES.N)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_demo43_main3);
        textView = findViewById(R.id.demo43Tv);
        Demo43CheckNetwork network = new Demo43CheckNetwork(getApplicationContext());
        network.dangKyMang();
        if(Demo43NetworkAvailable.isNetworkConnected)
        {
            textView.setText("Da ket noi thanh cong voi internet");
        }
        else
        {
            textView.setText("Ket noi internet that bai");
        }

    }
}
