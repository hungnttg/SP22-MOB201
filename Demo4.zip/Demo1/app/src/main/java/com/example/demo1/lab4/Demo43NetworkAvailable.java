package com.example.demo1.lab4;

public class Demo43NetworkAvailable {
    public static boolean isNetworkConnected = false;
}
