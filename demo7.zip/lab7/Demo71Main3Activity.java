package com.example.demo1.lab7;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;

import com.example.demo1.R;
public class Demo71Main3Activity extends AppCompatActivity {
    ImageView imageView1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_demo71_main3);
        imageView1 = findViewById(R.id.demo71Img);
        zoom();
    }
    public void zoom()
    {
        Animation animation
                = AnimationUtils.loadAnimation(getApplicationContext(),R.anim.anim_demo4);
        imageView1.setAnimation(animation);
    }
}
