package com.example.demo1.lab7;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;

import com.example.demo1.R;
public class Demo76Main3Activity extends AppCompatActivity {
    ImageView imgGio, imgPhut, imgGiay;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_demo76_main3);
        imgGio = findViewById(R.id.demo76ImgHour);
        imgPhut = findViewById(R.id.demo76ImgMinute);
        imgGiay = findViewById(R.id.demo76ImgSecond);
        chayDongHo();
    }
    public void chayDongHo()
    {
        Animation giay= AnimationUtils.loadAnimation(getApplicationContext(),R.anim.anim_giay);
        imgGiay.startAnimation(giay);
        Animation phut= AnimationUtils.loadAnimation(getApplicationContext(),R.anim.anim_phut);
        imgPhut.startAnimation(phut);
        Animation gio= AnimationUtils.loadAnimation(getApplicationContext(),R.anim.anim_gio);
        imgGio.startAnimation(gio);
    }
}
