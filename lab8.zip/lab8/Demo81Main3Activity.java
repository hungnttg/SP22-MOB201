package com.example.demo1.lab8;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.hardware.Camera;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.example.demo1.R;
public class Demo81Main3Activity extends AppCompatActivity {
    Button button;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_demo81_main3);
        button = findViewById(R.id.demo81Btn);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                access_Camera();
            }
        });
    }
    public void access_Camera()
    {
        int cams = Camera.getNumberOfCameras();
        if(cams>0)
        {
            Toast.makeText(getApplicationContext(),"Thiet bi co "+cams+" camera",
                    Toast.LENGTH_LONG).show();
            Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            this.startActivity(intent);
        }
        else
        {
            Toast.makeText(getApplicationContext(),"Thiet KHONG bi co camera",
                    Toast.LENGTH_LONG).show();
        }
    }
}
