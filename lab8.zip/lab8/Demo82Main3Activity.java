package com.example.demo1.lab8;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentResolver;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import com.example.demo1.R;

import java.io.File;
import java.lang.reflect.Field;
import java.util.ArrayList;

public class Demo82Main3Activity extends AppCompatActivity {
    Button btnStart, btnStop;
    ListView listView;
    MediaPlayer mediaPlayer;
    ArrayList<String> lsName = new ArrayList<>();
    ArrayList<Uri> lsUri = new ArrayList<>();
    public void getListRaw()
    {
        Field[] fields = R.raw.class.getFields();
        for(int i=0;i<fields.length;i++)
        {
            lsName.add(fields[i].getName());//them ten file nhac vao list
            Uri uri = getRawUri(fields[i].getName());
        }
    }
    public Uri getRawUri(String fileName)
    {
        return Uri.parse(ContentResolver.SCHEME_ANDROID_RESOURCE+
                        File.pathSeparator+File.separator+File.separator+
                getPackageName()+"/raw/"+fileName);
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_demo82_main3);
        btnStart = findViewById(R.id.demo82BtnStart);
        btnStop = findViewById(R.id.demo82BtnStop);
        listView  =findViewById(R.id.demo82Listview);
        getListRaw();//lay ve danh sach file nhac va dua vao lsName
        ArrayAdapter<String> arrayAdapter = new ArrayAdapter<>(getApplication(),
                android.R.layout.simple_list_item_1,lsName);
        listView.setAdapter(arrayAdapter);
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                try {
                    mediaPlayer.reset();
                }
                catch (Exception e)
                {
                    Toast.makeText(getApplicationContext(),e.getMessage(),Toast.LENGTH_LONG).show();
                }
                String name = lsName.get(position);//lay ve file nhac click
                Uri uri2 =getRawUri(name);//lay ve duong dan file nhac
                mediaPlayer = MediaPlayer.create(getApplicationContext(),uri2);
                mediaPlayer.start();

            }
        });
        btnStop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    mediaPlayer.stop();
                }catch (Exception e)
                {
                    Toast.makeText(getApplicationContext(),e.getMessage(),Toast.LENGTH_LONG).show();
                }
            }
        });
        //mo file nhac online
        btnStart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String url = "https://hungnttg.github.io/aksmm.mp3";
                try {
                    mediaPlayer = MediaPlayer.create(getApplicationContext(),
                    Uri.parse(url));
                    mediaPlayer.start();
                    mediaPlayer.prepare();
                }
                catch (Exception e)
                {

                }
            }
        });
    }
}
